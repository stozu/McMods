# Improvement Mods (WIP)

A list of improvement mods for 1.12.x forge/fabric versions.

Any suggestions/complaints?

Join our [discord](https://discord.gg/8nzHYhVUQS) or use the issues.

[![Bisect Hosting Image](https://raw.githubusercontent.com/TheUsefulLists/assets/main/Images/Promo.png)](https://bisecthosting.com/UsefulLists)
We have partnered with BisectHosting this is an exciting step for us. All money earned from this will go to the staff of UsefulLists, not including myself (Kevsky).

[![Home](https://raw.githubusercontent.com/TheUsefulLists/assets/main/Images/Buttons/Small/Home.png)](/README.md)
