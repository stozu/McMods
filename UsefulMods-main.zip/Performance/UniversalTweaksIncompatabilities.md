

| Author          | Name                            | Notes |
|-----------------|---------------------------------|-------|
| sr2610          | Creeper Confetti                |       |
| matthewprenger  | HelpFixer                       |       |
| parker8283      | Bow Infinity Fix (Forge/Fabric) |       |
| lumien231       | Quick Leaf Decay                |       |
| olafskiii       | Fast Leaf Decay                 |       |
| queenofmissiles | AI Improvements                 |       |
| icynewyear      | Easy Breeding                   |       |
| mezz            | No Potion Shift                 |       |
| aroma1997       | StepupFixer                     |       |
| jikuja          | LocaleFixer                     |       |
| darkhaxdev      | Surge                           |       |
| wildbamaboy     | Classic Combat                  |       |
| therealp455w0rd | Fence Jumper                    |       |
| by the009       | MTQFix                          |       |
| by exidex       | SwingThroughGrass               |       |
| frinn38            | Infinite Music                |   |
| ForgeUser27808417 | Mending Fix                   |   |
| flaxbeard          | Finite Water Control          |   |
| heckinchloe        | I Know What I'm Doing (IKWID) |   |
| bdew               | Leaf Decay Accelerator        |   |
| mjaroslav          | Villager Mantle Fix           |   |
| hrznstudio         | Water Control Extreme         |   |
| rwtema             | Diet Hoppers                  |   |
| tterrag1098        | Better Placement              |   |
| darkhaxdev         | AttributeFix                  |   |
| thiakil            | Gotta Go Fast                 |   |
| seneschal_luwin    | No Recipe Book                |   |
| xnrand             | MovingQuickly                 |   |
| unnoen             | Unloader                      |   |
| shadows_of_fire    | FastWorkbench                 |   |
| mrbysco            | Rally Health                  |   |
| teamcofh        | No Night Vision Flashing            |   |
| drullkus        | Shield Parry                        |   |
| modmuss50       | Enable Cheats                       |   |
| cas_ual_ty      | DEUF - Duplicate Entity UUID Fix    |   |
| animefan8888    | Entity NaN Health Fix               |   |
| orecruncher     | TidyChunk                           |   |
| gigaherz        | Configurable Cane                   |   |
| shadows_of_fire | Stable Thaumometer                  |   |
| shedaniel       | Smooth Scrolling Everywhere (Forge) |   |
| laike_endaril   | Login HP Fix                        |   |
| rakambda        | OverpoweredMending (Forge&Fabric)   |   |
| krokoonair      | Super Hot                           |   |
| barteks2x       | ChunkGenLimiter                     |   |
| darkhaxdev      | Better Burning                      |   |
| yungnickyoung   | Save My Stronghold! (Forge)         |   |
| lothrazar       | Stupid Horse Stand Still            |   |
| atlasthe1st      | Bottom Sugar Cane Harvest                               |   |
| rune_smith98     | End Portal Parallax                                     |   |
| bl4ckscor3       | Get It Together, Drops!                                 |   |
| charles445       | Damage Tilt                                             |   |
| mactso           | Fix Experience Bug (now with FABRIC and FORGE versions) |   |
| fonnymunkey      | Collision Damage                                        |   |
| phantamanta44    | Give Me Back My HP                                      |   |
| fonnymunkey      | BedBreakBegone                                          |   |
| youyihj          | Tinkers OreDict Cache                                   |   |
| meldexun         | Block Overlay Fix                                       |   |
| meldexun         | Entity Desync Fix                                       |   |
| acgaming56       | DrawerFPS Legacy                                        |   |
| acgaming56       | Configurable Item Entities (CIE)                        |   |
| frikinjay1       | Let Me Despawn                                          |   |
| the_computerizer | Dark Redstone                                           |   |
| fonnymunkey      | Frame Void Patch (MC-59363)                             |   |
